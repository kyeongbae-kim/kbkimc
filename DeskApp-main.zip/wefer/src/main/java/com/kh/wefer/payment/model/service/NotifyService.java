package com.kh.wefer.payment.model.service;

import com.kh.wefer.payment.model.domain.Notify;

public interface NotifyService {
	public int insertNotify(Notify vo);	
}
