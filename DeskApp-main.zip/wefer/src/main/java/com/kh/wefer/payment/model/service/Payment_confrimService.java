package com.kh.wefer.payment.model.service;

public interface Payment_confrimService {
//	int insertPaymentConfirm(Payment_confirm Payment_id); //Payment_id 시퀀스
}
