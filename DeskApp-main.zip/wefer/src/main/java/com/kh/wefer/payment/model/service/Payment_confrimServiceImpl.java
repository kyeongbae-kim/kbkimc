package com.kh.wefer.payment.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.wefer.payment.model.dao.AnnualDao;
import com.kh.wefer.payment.model.dao.PaymentDao;
import com.kh.wefer.payment.model.dao.Payment_confrimDao;
import com.kh.wefer.payment.model.domain.Payment;
import com.kh.wefer.payment.model.domain.Payment_confirm;

@Service("pcService")
public class Payment_confrimServiceImpl implements Payment_confrimService {
	
}
